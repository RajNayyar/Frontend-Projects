// Select color input
// Select size input
// When size is submitted by the user, call makeGrid()

function makeGrid() {
  var weight = document.getElementById("inputWeight").value; //get weight 
  var height = document.getElementById("inputHeight").value; //get height 
  var table = document.getElementById("pixelCanvas");
  table.innerHTML = '';
  var i,j,col,row;
  for (i=0;i<height;i++){
      row=table.insertRow(i); // creating row
     for (j=0;j<weight;j++){
        col=row.insertCell(j); //creating coloumn
      //click event for a cell 
      col.addEventListener("click",  function(event) {
        event.target.style.backgroundColor = document.getElementById("colorPicker").value; //colouring cells
      });
    }
  }
}

// creating submit action
document.getElementById("sizePicker").onsubmit = function() {
  event.preventDefault();
  makeGrid(); 
};

 